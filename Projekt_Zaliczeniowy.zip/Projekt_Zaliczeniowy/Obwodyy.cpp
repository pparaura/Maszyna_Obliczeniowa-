#include <iostream>
using namespace std;

class Kwadrat
{
private:
        float a;
public:
    Kwadrat(float bok)
    {
        a=bok;
    };
void Obwod()
    {
        cout << "Obwod wynosi "<<4*a<<endl;
    }
};

class Trojkat
{
private:
        float a,b,c;
public:
    Trojkat(float bok, float drugi_bok, float trzeci_bok)
    {
        a=bok;
        b=drugi_bok;
        c=trzeci_bok;
    };
void Obwod()
    {
        cout << "Obwod wynosi "<<a+b+c<<endl;
    }
};

class Prostokat
{
private:
        float a,b;
public:
    Prostokat(float bok, float drugi_bok )
    {
        a=bok;
        b=drugi_bok;
    };
void Obwod()
    {
        cout << "Obwod wynosi "<<2*a+2*b<<endl;
    }
};

class Trapez
{
private:
        float a,b,c,d;
public:
    Trapez(float bok, float drugi_bok, float trzeci_bok, float czwarty_bok )
    {
        a=bok;
        b=drugi_bok;
        c=trzeci_bok;
        d=czwarty_bok;
    };
void Obwod()
    {
        cout << "Obwod wynosi "<<a+b+c+d<<endl;
    }
};

