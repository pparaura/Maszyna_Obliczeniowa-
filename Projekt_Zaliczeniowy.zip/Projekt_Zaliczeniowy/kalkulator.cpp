#include <iostream>

using namespace std;

class Dodawanie
{
private:
        float a,b;
public:
    Dodawanie(float pierwsza_liczba, float druga_liczba)
    {
        a=pierwsza_liczba;
        b=druga_liczba;
    };
void dodawanie()
    {
        cout << "Wynik dodawania wynosi: "<<a+b<<endl;
    }
};

class Odejmowanie
{
private:
        float a,b;
public:
    Odejmowanie(float pierwsza_liczba, float druga_liczba)
    {
        a=pierwsza_liczba;
        b=druga_liczba;
    };
void odejmowanie()
    {
        cout << "Wynik odejmowania wynosi:  "<<a-b<<endl;
    }
};

class Mnozenie
{
private:
        float a,b;
public:
    Mnozenie(float pierwsza_liczba, float druga_liczba)
    {
        a=pierwsza_liczba;
        b=druga_liczba;
    };
void mnozenie()
    {
        cout << "Wynik mnozenia wynosi: "<<a*b<<endl;
    }
};

class Dzielenie
{
private:
        float a,b;
public:
    Dzielenie(float pierwsza_liczba, float druga_liczba)
    {
        a=pierwsza_liczba;
        b=druga_liczba;
    };
void dzielenie()
    {
        cout << "Wynik dzielenia wynosi: "<<a/b<<endl;
    }
};

class Potega
{
private:
        float a,b;
public:
    Potega(float pierwsza_liczba, float druga_liczba)
    {
        a=pierwsza_liczba;
        b=druga_liczba;
    };
void potega()
    {
        cout << "Wynik potegi wynosi: "<<pow(a,b)<<endl;
    }
};

class Pierwiastek
{
private:
        float a,b;
public:
    Pierwiastek(float liczba, float stopien)
    {
        a=liczba;
        b=stopien;

    };
void pierwiastek()
    {
        cout << "Wynik pierwiastka z podanej liczby wynosi: "<<pow(a, 1/b)<<endl;
    }
};

