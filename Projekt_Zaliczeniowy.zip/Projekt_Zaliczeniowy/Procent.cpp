#include <iostream>
using namespace std;

class Procent
{
private:
        float f,v;
        int d=100;
public:
    Procent(float liczba, float procent)
    {
        f=liczba;
        v=procent;
    };
void Pprocent()
    {
        cout<<v<<"%"<<" liczby "<<f<<" wynosi: "<<v/d*f<<endl;
    }
};
