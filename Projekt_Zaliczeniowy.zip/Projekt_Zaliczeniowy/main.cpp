#include <iostream>
#include <math.h>
#include <windows.h>
#include <conio.h>
#include <string>
#include <stdio.h>
#include <cstdlib>
#include "Obwodyy.cpp"
#include "Pola.cpp"
#include "Procent.cpp"
#include "Leasing.cpp"
#include <iomanip>
#include "kalkulator.cpp"
//#include "Logowanie.cpp"


using namespace std;

//-----------------------------------6---------------------------
    bool czy_pierwsza(int g){


	if(g<2)
		return false;

	for(int i=2;i*i<=g;i++)
		if(g%i==0)
			return false;
	return true;
}

//---------------------------------3---------------------------

void dec_to_bin(int liczba)
{
	int i=0,tab[31];

	while(liczba)
	{
		tab[i++]=liczba%2;
		liczba/=2;
	}

	for(int j=i-1;j>=0;j--)
		cout<<tab[j];
}

//---------------------------------4-------------------------------

string dec2hex (int dziesietna)
{
    char heksadecymalna[255];
    itoa(dziesietna, heksadecymalna, 16);

    return (string)heksadecymalna;
}

//---------------------------------8----------------------------------



string szyfruj(string tekst, int klucz[], int n){

	string wynik;
	int dl=tekst.size();
	int w=ceil((double)dl/n);

	char tablica [w][n];

	int i=0;
	for(int y=0;y<w;y++){
		for(int x=0;x<n;x++){
			if(i<dl){
				tablica[y][x]=tekst[i++];
			}else{
				tablica[y][x] = '\0';
			}
		}
	}


	for(int x=0;x<n;x++){
		for(int y=0;y<w;y++){
			if(tablica[y][klucz[x]]!='\0'){
				wynik=wynik+tablica[y][klucz[x]];
			}
		}
	}

	return wynik;
}




//---------------------------------------------------------------

int main(int argc, char *argv[])
{




    string nazwaUzytkownika;
    string hasloUzytkownika;
    int iloscProb = 0;

    while (iloscProb < 5)
    {
        cout << ">Prosze wprowadzic swoj login: ";
        cin >> nazwaUzytkownika;
        cout << ">Prosze wprowadzic swoje haslo: ";
        cin >> hasloUzytkownika;

        if (nazwaUzytkownika == "Adam" && hasloUzytkownika == "1234")
        {
            cout << ">Witaj Adam :)!\n";
            break;
        }
        else if (nazwaUzytkownika == "Piotr" && hasloUzytkownika == "4321")
        {
            cout << ">Witaj Piot :)!\n";
            break;
        }
        else
        {
            cout << ">Niepoprawne dane logowania, sprobuj ponownie" << '\n';
            iloscProb++;
        }
    }
    if (iloscProb == 5)
    {
            cout << ">Zbyt duzo prob logowania, awaryjne zamkniecie.";
            return 0;
    }

    cout << ">Milego korzystania z wirtualnej maszyny!.\n";
    cout <<  " " << endl;
    cout <<  " " << endl;
    cout <<  " " << endl;



system("COLOR 09");

HANDLE h= GetStdHandle(STD_OUTPUT_HANDLE);




  while(true){

    bool zmienna1=true;

    int x = 0;
    //while(x>13 || x<1)
    {
SetConsoleTextAttribute(h,11);
cout <<".88b  d88.  .d8b.  .d8888. d88888D db    db d8b   db  .d8b.        .d88b.  d8888b. db      d888888b  .o88b. d88888D d88888b d8b   db d888888b  .d88b.  db   d8b   db  .d8b.  "<<endl;
cout <<"88'YbdP`88 d8' `8b 88'  YP YP  d8' `8b  d8' 888o  88 d8' `8b      .8P  Y8. 88  `8D 88        `88'   d8P  Y8 YP  d8' 88'     888o  88   `88'   .8P  Y8. 88   I8I   88 d8' `8b "<<endl;
cout <<"88  88  88 88ooo88 `8bo.      d8'   `8bd8'  88V8o 88 88ooo88      88    88 88oooY' 88         88    8P         d8'  88ooooo 88V8o 88    88    88    88 88   I8I   88 88ooo88 "<<endl;
cout <<"88  88  88 88~~~88   `Y8b.   d8'      88    88 V8o88 88~~~88      88    88 88~~~b. 88         88    8b        d8'   88~~~~~ 88 V8o88    88    88    88 Y8   I8I   88 88~~~88 "<<endl;
cout <<"88  88  88 88   88 db   8D  d8' db    88    88  V888 88   88      `8b  d8' 88   8D 88booo.   .88.   Y8b  d8  d8' db 88.     88  V888   .88.   `8b  d8' `8b d8'8b d8' 88   88 "<<endl;
cout <<"YP  YP  YP YP   YP `8888Y' d88888P    YP    VP   V8P YP   YP       `Y88P'  Y8888P' Y88888P Y888888P  `Y88P' d88888P Y88888P VP   V8P Y888888P  `Y88P'   `8b8' `8d8'  YP   YP "<<endl;
SetConsoleTextAttribute(h,10);
cout << "           " << endl;

cout << setw(172) << setfill(' ') << "Wykonali: Piotr Parapura, Adam Zgutka" << endl;
cout << "           " << endl;
cout << "           " << endl;
SetConsoleTextAttribute(h,14);
    cout <<"Prosze wybrac operacje wpisujac przypisana jej liczbe, nastepnie zatwierdzic wybor klawiszem enter."<<endl;
    cout <<"------------------------------"<<endl;
    cout <<"1.  Wypisywanie wszystkich liczb pierwszych do podango zakresu."<<endl;
    cout <<"2.  Wypisywanie wszystkich dzielnikow wprowadzonej liczby."<<endl;
    cout <<"3.  Konwersja wprowadzonej liczby w systemie dziesietnym na system binarny."<<endl;
    cout <<"4.  Konwersja wprowadzonej liczby w systemie dziesietnym na system szesnastkowy."<<endl;
    cout <<"5.  Obliczanie delty"<<endl;
    cout <<"6.  Badanie czy podana liczba jest liczba pierwsza."<<endl;
    cout <<"7.  Obliczanie procentu danej liczby."<<endl;
    cout <<"8.  Szyfrowanie danych."<<endl;
    cout <<"9.  Klakulator podstawowy."<<endl;
    cout <<"10. Kalkulator leasingowy."<<endl;
    cout <<"11. Obliczanie obwodow figur geometrycznych."<<endl;
    cout <<"12. Obliczanie pol figur geometrycznych"<<endl;
    cout <<"13. Wyjscie z programu."<<endl;
    cout <<"------------------------------"<<endl;
    cout <<"Wybieram: "; cin>>x;






    system("cls");

     }



















    switch (x)
    {
       case 1:{//--------------------------------------------------1-----------------------------------------------

   int n;

    cout<<"Podaj liczbe do ktorej wypisane beda wszysstkie liczby pierwsze: ";

    cin>>n;
    cout<<"-----------------------------"<<endl;

    cout<<"Wszystkie liczby pierwsze do liczby "<<n<<"."<<endl;
    cout<<"-----------------------------"<<endl;


    bool liczby[n+1];

    for(int i=0;i<n; i++){

        liczby[i]=true;



    }


    liczby[1]=false;

    for(int i=2;i<=sqrt(n);i++){

        if(liczby[i]==true){

             for(int j=i+i;j<n;j=j+i){

                liczby[j]=false;





            }







        }

    }







    for(int i=1;i<n;i++){

        if(liczby[i]==true){


            cout<<i<<endl;



        }


    }


cout<<"-----------------------------"<<endl;


getch();

			 }break;
       case 2:{//--------------------------------------------------2-----------------------------------------------




	int p;

	cout<<"Podaj liczbe ktorej dzielniki chcesz sprawdzic : ";
	cin>> p;
cout<<"-----------------------------"<<endl;
cout<<"Wszystkie dzielniki liczby "<<p<<"."<<endl;
cout<<"-----------------------------"<<endl;

	for(int i=1;i<=p;i++){
		if(p%i==0){



			cout<<i<<endl;


		}
	}


cout<<"-----------------------------"<<endl;
getch();

             } break;
       case 3:{//------------------------------------------------3------------------------------------------



             int liczba;

	cout<<"Podaj liczbe do zamiany z zapisu dziesietnego na zapis binarny: ";


	cin>>liczba;
    cout<<"-----------------------------"<<endl;

	cout<<liczba<<" na system binarny to: ";


	dec_to_bin(liczba);
	cout<<endl;

	cout<<"-----------------------------"<<endl;


getch();



              }break;
       case 4:{//-------------------------------------------------4-----------------------------------------



			   int liczba;

    cout << "Podaj liczbe do zamiany z zapisu dziesietnego na zapis szesnastkowy: ";


    cin >> liczba;
    cout<<"-----------------------------"<<endl;

    cout <<"Liczba "<<liczba<<" w systemie szesnasstkowym to " << dec2hex(liczba) << endl;
    cout<<"-----------------------------"<<endl;




getch();



		      }break;
       case 5:{//--------------------------------------------------5-------------------------------------

			    float a, b, c, delta, x0, x1, x2; //zmienne dla delty


            cout << "Podaj liczbe (a): ";
            cin >> a;
            cout << "Podaj liczbe (b): ";
            cin >> b;
            cout << "Podaj liczbe (c):";
            cin >> c;
            cout<<"-----------------------------"<<endl;
            delta = (b * b) - (4 * a * c); //wzor delta

            cout << "Delta wynosi: " << delta << endl;
            cout<<"-----------------------------"<<endl;
            cout << "Pierwiastek z delty wynosi " << sqrt(delta) << endl; //math.h sqrt czyli pierwiastek z delty
            cout<<"-----------------------------"<<endl;
            if (delta > 0) { //instrukcja warunkowa IF
                cout << "x1=" << (-b - sqrt(delta)) / 2 * a << endl; //obliczenie x1
                cout << "x2=" << (-b + sqrt(delta)) / 2 * a << endl; //obliczenie x2
                cout<<"-----------------------------"<<endl;
                cout << "Delta ma dwa rozwiazania! "<<endl;
                cout<<"-----------------------------"<<endl;
            } else if (delta == 0) {
                cout << "x0=" << (-b) / 2 * a << endl; //obliczenie x0
                cout << "Delta ma jedno rozwiazanie!"<<endl;
                cout<<"-----------------------------"<<endl;
            } else if (delta < 0) {
                cout << "Delta nie ma rozwiazan! "<<endl;
                cout<<"-----------------------------"<<endl;
            }





getch();




			  }break;
	   case 6:{//------------------------------------------------6-------------------------------------------

	   	int g;

	cout<<"Podaj liczbe ktora chcesz sprawdzic czy jest liczba pierwsza:";
	cin>>g;

	if(czy_pierwsza(g)){



        cout<<"-----------------------------"<<endl;
		cout<<"Liczba "<<g<<" jest liczba pierwsza"<<endl;
        cout<<"-----------------------------"<<endl;

	}else{


	    cout<<"-----------------------------"<<endl;
	    cout<<"Liczba "<<g<<" nie jest licza pierwsza"<<endl;
        cout<<"-----------------------------"<<endl;
		}


getch();

              }break;
       case 7:{//-----------------------------------------------7------------------------------------------


    float f,v;
    int d=100;
    cout<<"Podaj liczbe ktorej procent chcesz obliczyc"<<endl;
    cin>>f;
    cout<<"Podaj procent jaki chcesz obliczyc"<<endl;
    cin>>v;

    Procent kw = Procent(f,v);

    cout<<"-----------------------------"<<endl;
    kw.Pprocent();
    cout<<"-----------------------------"<<endl;





getch();



		      }break;
       case 8:{//-----------------------------------------------8----------------------------------------


    cout<<"Wprowadz tekst jaki chcesz zaszyfrowac: "<<endl;
    cout<<"-----------------------------"<<endl;

    string x;

	int klucz[]={2,1,4,0,3};
	cin>>x;
	cout<<"-----------------------------"<<endl;
	cout<<"Zaszyfrowany tekst: "<<szyfruj( x , klucz,5)<<endl;
	cout<<"-----------------------------"<<endl;
getch();

              }break;
       case 9:{//---------------------------------------------9------------------------------------------

while(zmienna1){


             int l = 0;
    while(l>7 || l<1){


	cout<<"-----------------------------"<<endl;
    cout<<"Prosze wybrac operacje wpisujac przypisana jej liczbe, nastepnie zatwierdzic wybor klawiszem enter."<<endl;
    cout<<"-----------------------------"<<endl;
    cout<<"1. Dodawanie."<<endl;
    cout<<"2. Odejmowanie."<<endl;
    cout<<"3. Mnozenie."<<endl;
    cout<<"4. Dzielenie."<<endl;
	cout<<"5. Pierwiastkowanie."<<endl;
	cout<<"6. Potegowanie."<<endl;
	cout<<"7. Powrot do menu."<<endl;
	cout<<"-----------------------------"<<endl;
	cout<<"Wybieram: "; cin>>l;


                        switch (l)
    {
       case 1:{

       	float a,b;

       	cout<<"Podaj pierwsza liczbe:"<<endl;
       	cin>>a;
       	cout<<"Podaj druga liczbe:"<<endl;
       	cin>>b;


       	Dodawanie kw = Dodawanie(a,b);

       	cout<<"-----------------------------"<<endl;
       	kw.dodawanie();
       	cout<<"-----------------------------"<<endl;

getch();

             }break;

	   case 2:{

	   float a,b;
	   cout<<"Podaj pierwsza liczbe:"<<endl;
	   cin>>a;
	   cout<<"Podaj druga liczbe:"<<endl;
	   cin>>b;

	   Odejmowanie kw = Odejmowanie(a,b);

	   cout<<"-----------------------------"<<endl;
	   kw.odejmowanie();
	   cout<<"-----------------------------"<<endl;

getch();
              }break;
       case 3:{

	   float a,b;
	   cout<<"Podaj pierwsza liczbe:"<<endl;
	   cin>>a;
	   cout<<"Podaj druga liczbe:"<<endl;
	   cin>>b;

       Mnozenie kw = Mnozenie(a,b);

	   cout<<"-----------------------------"<<endl;
	   kw.mnozenie();
	   cout<<"-----------------------------"<<endl;
getch();

              }break;
       case 4:{

       float a,b;
       cout<<"Podaj pierwsza liczbe:"<<endl;
       cin>>a;
       cout<<"Podaj druga liczbe:"<<endl;
       cin>>b;

       Dzielenie kw = Dzielenie(a,b);

       cout<<"-----------------------------"<<endl;
       kw.dzielenie();
       cout<<"-----------------------------"<<endl;


getch();



              }break;
        case 5:{

        float a,b;
       cout<<"Podaj liczbe podpierwiastkowa:"<<endl;
       cin>>a;
       cout<< "Podaj stopien pierwiastka: ";
       cin>>b;

       Pierwiastek kw = Pierwiastek(a,b);

       cout<<"-----------------------------"<<endl;
       kw.pierwiastek();
       cout<<"-----------------------------"<<endl;





getch();



            }break;
        case 6:{

        float a,b;
       cout<<"Podaj podstawe potegi:"<<endl;
       cin>>a;
       cout<<"Podaj wykladnik potegi:"<<endl;
       cin>>b;

       Potega kw = Potega(a,b);

       cout<<"-----------------------------"<<endl;
       kw.potega();
       cout<<"-----------------------------"<<endl;


getch();

        }break;








	   case 7:{


//cout<<"Prosze potwierdzic klawiszem enter."<<endl;

zmienna1 = false;


		      }break;


	}





	}




system("cls");


}
       }






            break;
       case 10:{//---------------------------------------------10----------------------------------------


			float a,b;
			int c;
			cout<<"Prosze podac kwote przedmiotu: "<<endl;

			cin>>a;

			cout<<"Prosze podac kwote wkladu wlasnego: "<<endl;

			cin>>b;

			cout<<"Prosze podac ilo�c rat miesiecznych: "<<endl;

	        cin>>c;

	        Leasing kw = Leasing(a,b,c);

	        cout<<"-----------------------------"<<endl;
			kw.raty();
			cout<<"-----------------------------"<<endl;










getch();

			  }break;
	   case 11:{//-------------------------------------------11--------------------------------------------


while(zmienna1){




			 int l = 0;
    while(l>5 || l<1){


	cout<<"-----------------------------"<<endl;
    cout<<"Prosze wybrac operacje wpisujac przypisana jej liczbe, nastepnie zatwierdzic wybor klawiszem enter."<<endl;
    cout<<"-----------------------------"<<endl;
    cout<<"1. Trojkat."<<endl;
    cout<<"2. Prostokat."<<endl;
    cout<<"3. Kwadrat."<<endl;
    cout<<"4. Trapez."<<endl;
	cout<<"5. Powrot do menu."<<endl;
	cout<<"-----------------------------"<<endl;
	cout<<"Wybieram: "; cin>>l;
	cout<<"-----------------------------"<<endl;


			  switch (l)
    {
       case 1:{

       	float a,b,c;

       	cout<<"Podaj pierwszy bok trojkata:"<<endl;
       	cin>>a;
       	cout<<"Podaj drugi bok trojkata:"<<endl;
       	cin>>b;
       	cout<<"Podaj trzeci bok trojkata:"<<endl;
       	cin>>c;

       	Trojkat kw = Trojkat(a,b,c);

       	cout<<"-----------------------------"<<endl;
       	kw.Obwod();
       	cout<<"-----------------------------"<<endl;

getch();

             }break;

	   case 2:{

	   float a,b;
	   cout<<"Podaj krotszy bok prostokata:"<<endl;
	   cin>>a;
	   cout<<"Podaj dluzszy bok prostokata:"<<endl;
	   cin>>b;

	   Prostokat kw = Prostokat(a,b);

	   cout<<"-----------------------------"<<endl;
	   kw.Obwod();
	   cout<<"-----------------------------"<<endl;

getch();
              }break;
       case 3:{

	   float a;
	   cout<<"Podaj bok kwadratu:"<<endl;
	   cin>>a;

       Kwadrat kw = Kwadrat(a);

	   cout<<"-----------------------------"<<endl;
	   kw.Obwod();
	   cout<<"-----------------------------"<<endl;
getch();

              }break;
       case 4:{

       float a,b,c,d;
       cout<<"Podaj dlugosc pierwszej podstawy:"<<endl;
       cin>>a;
       cout<<"Podaj dlugosc drugiej podstawy:"<<endl;
       cin>>b;
       cout<<"Podaj dlugosc boku:"<<endl;
       cin>>c;
       cout<<"Podaj dlugosc drugiego boku:"<<endl;
       cin>>d;

       Trapez kw = Trapez(a,b,c,d);

       cout<<"-----------------------------"<<endl;
       kw.Obwod();
       cout<<"-----------------------------"<<endl;


getch();



              }break;
	   case 5:{


//cout<<"Prosze potwierdzic klawiszem enter."<<endl;

zmienna1 = false;


		      }break;


	}





	}




system("cls");


}



			  }break;
       case 12:{//---------------------------------------------12-----------------------------------------



while(zmienna1){


			 int l = 0;
    while(l>5 || l<1){


	cout<<"-----------------------------"<<endl;
    cout<<"Prosze wybrac operacje wpisujac przypisana jej liczbe, nastepnie zatwierdzic wybor klawiszem enter."<<endl;
    cout<<"-----------------------------"<<endl;
    cout<<"1. Trojkat."<<endl;
    cout<<"2. Prostokat."<<endl;
    cout<<"3. Kwadrat."<<endl;
    cout<<"4. Trapez."<<endl;
	cout<<"5. Powrot do menu."<<endl;
	cout<<"-----------------------------"<<endl;
	cout<<"Wybieram: "; cin>>l;
	cout<<"-----------------------------"<<endl;


			  switch (l)
    {
       case 1:{

       	float a,h;

       	cout<<"Podaj dlugosc podstawy trojkata:"<<endl;
       	cin>>a;
       	cout<<"Podaj dlugosc wysokosci trojkata:"<<endl;
       	cin>>h;

       	TrojkatP kw = TrojkatP(a,h);

       	cout<<"-----------------------------"<<endl;
       	kw.Pole();
       	cout<<"-----------------------------"<<endl;

getch();

             }break;

	   case 2:{

	   float a,b;
	   cout<<"Podaj krotszy bok prostokata:"<<endl;
	   cin>>a;
	   cout<<"Podaj dluzszy bok prostokata:"<<endl;
	   cin>>b;

	   ProstokatP kw = ProstokatP(a,b);

	   cout<<"-----------------------------"<<endl;
	   kw.Pole();
	   cout<<"-----------------------------"<<endl;

getch();
              }break;
       case 3:{

	   float a;
	   cout<<"Podaj bok kwadratu:"<<endl;
	   cin>>a;

	   KwadratP kw = KwadratP(a);

	   cout<<"-----------------------------"<<endl;
	   kw.Pole();
	   cout<<"-----------------------------"<<endl;
getch();

              }break;
       case 4:{

       float a,b,h;
       cout<<"Podaj dlugosc pierwszej podstawy:"<<endl;
       cin>>a;
       cout<<"Podaj dlugosc drugiej podstawy:"<<endl;
       cin>>b;
       cout<<"Podaj dlugosc wysokosci:"<<endl;
       cin>>h;

       TrapezP kw = TrapezP(a,b,h);

       cout<<"-----------------------------"<<endl;
       kw.Pole();
       cout<<"-----------------------------"<<endl;


getch();



              }break;
	   case 5:{


//cout<<"Prosze potwierdzic klawiszem enter."<<endl;

zmienna1 = false;






		      }break;


	}





	}




system("cls");


}




			  }break;
       case 13:{//-----------------------------------------------13------------------------------------------


   cout<<"Nacisnij Enter w celu zamkniecia programu"<<endl;


			exit(0);

			  }break;
   default: cout<<"Brak opcji w menu!"<<endl;

           }



system("cls");





}
    system("PAUSE");
    return 0;
}


