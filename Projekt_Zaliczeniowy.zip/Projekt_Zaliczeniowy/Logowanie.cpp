#include <iostream>
using namespace std;

class loginManager{
    public:
        string userNameAttempt;
        string passWordAttempt;
        loginManager(){
            accessGranted = 0;
    }
    void login(){
        cout << "Wprowadz dane Piot!\nUsername: ";
        cin >> userNameAttempt;
        if(userNameAttempt==userName){
            cout << "Password: ";
            cin >>passWordAttempt;
            if(passWordAttempt==passWord){
                cout << "Super!";
                }
            }
            }
    private:
        string passWord = "fortnitegurom";
        string userName = "zaliczenie";
        bool accessGranted;


};
