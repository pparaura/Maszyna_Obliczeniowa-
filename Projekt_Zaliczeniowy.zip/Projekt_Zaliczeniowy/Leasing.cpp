#include <iostream>
using namespace std;

class Leasing
{
private:
        float a,b;
        int c;
public:
    Leasing(float kwota_przedmiotu, float wklad_wlasny, int raty_miesieczne)
    {
        a=kwota_przedmiotu;
        b=wklad_wlasny;
        c=raty_miesieczne;
    };
void raty()
    {
        cout<<"Wysokosc raty miesiecznej wynosi: "<<(a-b)/c<<endl;
    }
};
