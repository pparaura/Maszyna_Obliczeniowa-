#include <iostream>
using namespace std;

class KwadratP
{
private:
        float a;
public:
    KwadratP(float bok)
    {
        a=bok;
    };
void Pole()
    {
        cout << "Pole wynosi: "<<a*a<<endl;
    }
};

class TrojkatP
{
private:
        float a,h;
public:
    TrojkatP(float bok, float wysokosc)
    {
        a=bok;
        h=wysokosc;
    };
void Pole()
    {
        cout << "Pole wynosi: "<<a*h/2<<endl;
    }
};

class ProstokatP
{
private:
        float a,b;
public:
    ProstokatP(float bok, float drugi_bok )
    {
        a=bok;
        b=drugi_bok;
    };
void Pole()
    {
        cout << "Pole wynosi: "<<a*b<<endl;
    }
};

class TrapezP
{
private:
        float a,b,h;
public:
    TrapezP(float bok, float drugi_bok, float wysokosc )
    {
        a=bok;
        b=drugi_bok;
        h=wysokosc;
    };
void Pole()
    {
        cout << "Pole wynosi "<<(a+b)*h/2<<endl;
    }
};
